#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Flashback — AI State Bus (WS-first account + market snapshot, hardened) — Snapshot v2

Purpose
-------
Provide AI / signal engines with a SINGLE, structured snapshot of:

- Account state:
    • equity_usdt, mmr_pct
    • tier, level
    • tier size cap %, max concurrent symbols

- Positions (per ACCOUNT_LABEL):
    • raw WS-fed rows (via position_bus)
    • by-symbol map for quick lookup
    • snapshot_age_sec (freshness of positions_bus.json)

- Market data (WS-first where available):
    • last_price_ws_first
    • spread_bps_ws
    • orderbook snapshot (bids/asks trimmed)
    • recent public trades (optional)
    • orderbook / trades bus ages (if market_bus exposes them)

Snapshot v2 additions
---------------------
- schema_version = 2
- freshness block + safety block (is_safe + reasons)
- stable return type (dict, not tuple)

PATCH (2025-12-14)
------------------
- If include_trades=False, DO NOT enforce trades_bus staleness.
  Otherwise AI Pilot gets blocked even though it doesn't request trades.
"""

from __future__ import annotations

import os

# Mirror of flashback_common.EXEC_DRY_RUN (avoid import coupling)
EXEC_DRY_RUN: bool = os.getenv("EXEC_DRY_RUN", "false").strip().lower() in ("1","true","yes","y","on")
import time
from decimal import Decimal
from typing import Any, Dict, List, Optional, Tuple

from app.core.flashback_common import (
    get_equity_usdt,
    get_mmr_pct,
    tier_from_equity,
    cap_pct_for_tier,
    max_conc_for_tier,
    last_price_ws_first,
    spread_bps_ws,
    record_heartbeat,
)

from app.core.position_bus import (
    get_positions_for_current_label,
    get_position_map_for_label,
    get_snapshot as _pos_get_snapshot,
)

try:
    from app.core import market_bus as _market_bus  # type: ignore
except Exception:
    _market_bus = None  # type: ignore


CATEGORY = "linear"
SNAPSHOT_SCHEMA_VERSION = 2

# Staleness thresholds (seconds) – tweak later via env
_POS_MAX_AGE_SEC = float(os.getenv("AI_POS_MAX_AGE_SEC", "8") or "8")
_OB_MAX_AGE_SEC = float(os.getenv("AI_OB_MAX_AGE_SEC", "5") or "5")
_TR_MAX_AGE_SEC = float(os.getenv("AI_TR_MAX_AGE_SEC", "8") or "8")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _now_ms() -> int:
    return int(time.time() * 1000)


def _decimal_to_str(d: Optional[Decimal]) -> Optional[str]:
    if d is None:
        return None
    return str(d)


def _safe_str(val: Any) -> Optional[str]:
    if val is None:
        return None
    try:
        return str(val)
    except Exception:
        return None


def _to_float(val: Any) -> Optional[float]:
    try:
        if val is None:
            return None
        return float(val)
    except Exception:
        return None


def _account_state() -> Dict[str, Any]:
    """
    Return core account state (REST-driven, WS-agnostic).
    All numeric fields are stringified so downstream JSON is stable.
    """
    eq = get_equity_usdt()
    mmr = get_mmr_pct()
    tier, level = tier_from_equity(eq)
    cap_pct = cap_pct_for_tier(tier)
    max_conc = max_conc_for_tier(tier)

    return {
        "equity_usdt": str(eq),
        "mmr_pct": str(mmr),
        "tier": tier,
        "level": level,
        "tier_size_cap_pct": str(cap_pct),
        "tier_max_conc": max_conc,
    }


def _positions_state() -> Dict[str, Any]:
    """
    Return WS-first positions for current ACCOUNT_LABEL.

    Structure:
        {
          "raw": [ ... Bybit rows ... ],
          "by_symbol": { "BTCUSDT": {...}, ... },
          "snapshot_age_sec": float | None
        }
    """
    snap_age_sec: Optional[float] = None
    try:
        _snap, age = _pos_get_snapshot()
        if age is not None:
            snap_age_sec = float(age)
    except Exception:
        snap_age_sec = None

    rows = get_positions_for_current_label(
        category=CATEGORY,
        max_age_seconds=None,
        allow_rest_fallback=True,
    )
    pos_map = get_position_map_for_label(
        label=None,
        category=CATEGORY,
        max_age_seconds=None,
        allow_rest_fallback=True,
    )

    norm_map: Dict[str, Dict[str, Any]] = {}
    for k, v in (pos_map or {}).items():
        norm_map[str(k).upper()] = v

    return {
        "raw": rows or [],
        "by_symbol": norm_map,
        "snapshot_age_sec": snap_age_sec,
    }


def _market_bus_ages() -> Tuple[Optional[float], Optional[float]]:
    """
    Try to expose global orderbook / trades bus ages, if market_bus provides them.
    Returns (orderbook_bus_age_sec, trades_bus_age_sec).
    """
    if _market_bus is None:
        return None, None

    ob_age: Optional[float] = None
    tr_age: Optional[float] = None

    try:
        if hasattr(_market_bus, "orderbook_bus_age_sec"):
            v = _market_bus.orderbook_bus_age_sec()  # type: ignore[attr-defined]
            if v is not None:
                ob_age = float(v)
    except Exception:
        ob_age = None

    try:
        if hasattr(_market_bus, "trades_bus_age_sec"):
            v = _market_bus.trades_bus_age_sec()  # type: ignore[attr-defined]
            if v is not None:
                tr_age = float(v)
    except Exception:
        tr_age = None

    return ob_age, tr_age


def _symbol_market_block(
    symbol: str,
    *,
    include_orderbook: bool,
    include_trades: bool,
    trades_limit: int,
) -> Dict[str, Any]:
    """
    Build a per-symbol market snapshot block.
    Uses WS-first sources where possible, falls back gracefully.
    """
    sym = symbol.upper()
    last_px = last_price_ws_first(sym)
    spread_bps_val = spread_bps_ws(sym)

    ob_block: Optional[Dict[str, Any]] = None
    trades_block: Optional[List[Dict[str, Any]]] = None
    ob_updated_ms: Optional[int] = None
    trades_updated_ms: Optional[int] = None

    if _market_bus is not None:
        try:
            if include_orderbook and hasattr(_market_bus, "get_orderbook_snapshot"):
                ob = _market_bus.get_orderbook_snapshot(sym)  # type: ignore[attr-defined]
                if isinstance(ob, dict):
                    bids = ob.get("bids") or ob.get("b") or []
                    asks = ob.get("asks") or ob.get("a") or []
                    ob_block = {
                        "bids": bids[:10],
                        "asks": asks[:10],
                        "ts_ms": ob.get("ts_ms", 0),
                        "updated_ms": ob.get("updated_ms", 0),
                    }
                    try:
                        ob_updated_ms = int(ob_block.get("updated_ms") or 0) or None
                    except Exception:
                        ob_updated_ms = None

            if include_trades and hasattr(_market_bus, "get_recent_trades"):
                trades = _market_bus.get_recent_trades(sym, limit=trades_limit)  # type: ignore[attr-defined]
                if isinstance(trades, list):
                    trades_block = trades

                if hasattr(_market_bus, "trades_bus_updated_ms"):
                    try:
                        trades_updated_ms = _market_bus.trades_bus_updated_ms()  # type: ignore[attr-defined]
                        if trades_updated_ms is not None:
                            trades_updated_ms = int(trades_updated_ms)
                    except Exception:
                        trades_updated_ms = None
        except Exception:
            pass

    return {
        "symbol": sym,
        "last_price": _safe_str(last_px),
        "spread_bps": _decimal_to_str(spread_bps_val),
        "orderbook": ob_block,
        "trades": trades_block,
        "orderbook_updated_ms": ob_updated_ms,
        "trades_updated_ms": trades_updated_ms,
    }


def _evaluate_snapshot_safety(
    *,
    positions_bus_age_sec: Optional[float],
    orderbook_bus_age_sec: Optional[float],
    trades_bus_age_sec: Optional[float],
) -> Dict[str, Any]:
    """
    Decide whether snapshot is "safe enough" to trade on.
    This is intentionally conservative.

    Rule: If a bus age exists and exceeds threshold -> unsafe.
    """
    reasons: List[str] = []
    is_safe = True

    # DRY_RUN: positions may be empty; do not fail safety on positions freshness
    if EXEC_DRY_RUN:
        positions_bus_age_sec = None

    if positions_bus_age_sec is not None and positions_bus_age_sec > _POS_MAX_AGE_SEC:
        is_safe = False
        reasons.append(
            f"positions_bus_stale ({positions_bus_age_sec:.2f}s > {_POS_MAX_AGE_SEC:.2f}s)"
        )

    if orderbook_bus_age_sec is not None and orderbook_bus_age_sec > _OB_MAX_AGE_SEC:
        is_safe = False
        reasons.append(
            f"orderbook_bus_stale ({orderbook_bus_age_sec:.2f}s > {_OB_MAX_AGE_SEC:.2f}s)"
        )

    # NOTE: If trades_bus_age_sec is None, we treat it as "not required".
    if trades_bus_age_sec is not None and trades_bus_age_sec > _TR_MAX_AGE_SEC:
        is_safe = False
        reasons.append(
            f"trades_bus_stale ({trades_bus_age_sec:.2f}s > {_TR_MAX_AGE_SEC:.2f}s)"
        )

    return {
        "is_safe": bool(is_safe),
        "reasons": reasons,
        "thresholds_sec": {
            "positions": _POS_MAX_AGE_SEC,
            "orderbook": _OB_MAX_AGE_SEC,
            "trades": _TR_MAX_AGE_SEC,
        },
    }


def validate_snapshot_v2(snapshot: Dict[str, Any]) -> Tuple[bool, List[str]]:
    """
    Lightweight schema validation. We keep it strict on core keys
    and flexible on the rest to avoid breaking iteration.

    Returns (ok, errors).
    """
    errors: List[str] = []
    if not isinstance(snapshot, dict):
        return False, ["snapshot_not_dict"]

    sv = snapshot.get("schema_version")
    if sv != SNAPSHOT_SCHEMA_VERSION:
        errors.append(f"schema_version_expected_{SNAPSHOT_SCHEMA_VERSION}_got_{sv}")

    for key in ("ts_ms", "account", "positions", "symbols", "freshness", "safety"):
        if key not in snapshot:
            errors.append(f"missing_key:{key}")

    # sanity types
    if "freshness" in snapshot and not isinstance(snapshot.get("freshness"), dict):
        errors.append("freshness_not_dict")
    if "safety" in snapshot and not isinstance(snapshot.get("safety"), dict):
        errors.append("safety_not_dict")

    return (len(errors) == 0), errors


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def build_symbol_state(
    symbol: str,
    *,
    include_trades: bool = True,
    trades_limit: int = 100,
    include_orderbook: bool = True,
) -> Dict[str, Any]:
    """
    Focused state snapshot for a SINGLE symbol.

    Returns dict:
        {
          "schema_version": 2,
          "ts_ms": ...,
          "account": {...},
          "position": {... or None},
          "market": {...},
          "freshness": {...bus ages...},
          "safety": {...is_safe, reasons, thresholds...}
        }
    """
    record_heartbeat("ai_state_bus_symbol")
    sym = symbol.upper()

    account = _account_state()
    positions = _positions_state()
    pos_map = positions.get("by_symbol", {}) or {}
    pos = pos_map.get(sym)

    market = _symbol_market_block(
        sym,
        include_orderbook=include_orderbook,
        include_trades=include_trades,
        trades_limit=trades_limit,
    )

    pos_age_sec = _to_float(positions.get("snapshot_age_sec"))

    # PATCH: only require trades bus freshness if include_trades=True
    ob_age_sec, tr_age_sec = _market_bus_ages()
    if not include_trades:
        tr_age_sec = None
    if not include_orderbook:
        ob_age_sec = None

    # DRY_RUN: positions freshness must not gate safety
    if EXEC_DRY_RUN:
        pos_age_sec = None

    freshness = {
        "positions_bus_age_sec": pos_age_sec,
        "orderbook_bus_age_sec": _to_float(ob_age_sec),
        "trades_bus_age_sec": _to_float(tr_age_sec),
    }

    safety = _evaluate_snapshot_safety(
        positions_bus_age_sec=freshness["positions_bus_age_sec"],
        orderbook_bus_age_sec=freshness["orderbook_bus_age_sec"],
        trades_bus_age_sec=freshness["trades_bus_age_sec"],
    )

    return {
        "schema_version": SNAPSHOT_SCHEMA_VERSION,
        "ts_ms": _now_ms(),
        "account": account,
        "position": pos,
        "market": market,
        "freshness": freshness,
        "safety": safety,
    }


def build_ai_snapshot(
    focus_symbols: Optional[List[str]] = None,
    *,
    include_trades: bool = False,
    trades_limit: int = 50,
    include_orderbook: bool = True,
) -> Dict[str, Any]:
    """
    Build a global AI snapshot for current ACCOUNT_LABEL.

    Returns dict (NOT tuple):
        {
          "schema_version": 2,
          "ts_ms": ...,
          "account": {...},
          "positions": {...},
          "symbols": {...},
          "freshness": {...bus ages...},
          "safety": {...is_safe, reasons, thresholds...}
        }
    """
    record_heartbeat("ai_state_bus_global")

    account = _account_state()
    positions = _positions_state()

    pos_age_sec = _to_float(positions.get("snapshot_age_sec"))

    # PATCH: only require trades bus freshness if include_trades=True
    ob_age_sec, tr_age_sec = _market_bus_ages()
    if not include_trades:
        tr_age_sec = None
    if not include_orderbook:
        ob_age_sec = None

    # Determine which symbols to include in market view
    symbols_set = set()
    if focus_symbols:
        for s in focus_symbols:
            s_norm = str(s).upper().strip()
            if s_norm:
                symbols_set.add(s_norm)
    else:
        for s in (positions.get("by_symbol", {}) or {}).keys():
            symbols_set.add(str(s).upper())

    symbols_block: Dict[str, Dict[str, Any]] = {}
    for sym in sorted(symbols_set):
        symbols_block[sym] = _symbol_market_block(
            sym,
            include_orderbook=include_orderbook,
            include_trades=include_trades,
            trades_limit=trades_limit,
        )

    # DRY_RUN: positions freshness must not gate safety
    if EXEC_DRY_RUN:
        pos_age_sec = None

    freshness = {
        "positions_bus_age_sec": pos_age_sec,
        "orderbook_bus_age_sec": _to_float(ob_age_sec),
        "trades_bus_age_sec": _to_float(tr_age_sec),
    }

    safety = _evaluate_snapshot_safety(
        positions_bus_age_sec=freshness["positions_bus_age_sec"],
        orderbook_bus_age_sec=freshness["orderbook_bus_age_sec"],
        trades_bus_age_sec=freshness["trades_bus_age_sec"],
    )

    snap: Dict[str, Any] = {
        "schema_version": SNAPSHOT_SCHEMA_VERSION,
        "ts_ms": _now_ms(),
        "account": account,
        "positions": positions,
        "symbols": symbols_block,
        "freshness": freshness,
        "safety": safety,
    }

    return snap
