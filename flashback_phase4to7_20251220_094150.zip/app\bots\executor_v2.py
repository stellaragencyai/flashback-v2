﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Flashback — Auto Executor v2 (Strategy-aware, multi-sub, AI-gated, policy-aware)

Patch (2025-12-13c)
-------------------
Adds AI decision emission to state/ai_decisions.jsonl so:
- ai_decision_enforcer has a real store to enforce from
- decision_outcome_linker can join decisions ↔ outcomes consistently
- TP/SL Manager can gate TP ladders by trade_id

Key behavior:
- PAPER: decision is emitted once with trade_id=client_trade_id
- LIVE: decision is emitted twice:
    1) pre-order (trade_id=client_trade_id)
    2) post-order (trade_id=orderId)  <-- joinable canonical trade_id

Patch (2025-12-13d)
-------------------
Adds decision enforcement + deterministic test hooks:
- EXEC_ENFORCE_DECISIONS=true (default): enforce_decision(trade_id) must ALLOW or trade is blocked.
- EXEC_FORCE_TRADE_ID=... (optional): override client_trade_id for deterministic tests (ex: BLOCK_TEST_1).
- If enforcer returns size_multiplier (ALLOW with scaling), sizing uses it deterministically.

Patch (2025-12-13e)
-------------------
HARD GATE moved BEFORE sizing:
- Decision enforcement happens immediately after client_trade_id creation
- size_multiplier is applied into eff_risk_pct BEFORE bayesian_size/risk_capped_qty/portfolio_guard

Patch (2025-12-13f) ✅ FIX
-------------------------
Executor now emits the *pilot legacy decision row* BEFORE enforcement.
ai_decision_enforcer only consumes:
  - manual override rows, or
  - pilot legacy rows (schema_version==1 and "decision" in payload)

So we:
  1) call pilot_decide(setup_event)
  2) append that dict to state/ai_decisions.jsonl
  3) then enforce_decision(trade_id)

Patch (2025-12-13g) ✅ FIX
-------------------------
Executor audit rows now reflect the *true enforced decision*:
- decision_code == enforced_code (ex: COLD_START) instead of always ALLOW_TRADE
- reason == enforced_reason
- extra includes enforced_code/enforced_reason/enforced_size_multiplier

Patch (2025-12-13h) ✅ FIX (Deterministic trade_id selection)
-------------------------------------------------------------
trade_id selection is now deterministic and priority-based:
  1) Prefer sig['trade_id'] (or sig['client_trade_id']) if present
  2) Else EXEC_FORCE_TRADE_ID
  3) Else generated default

Patch (2025-12-13i) ✅ FIX (Hardened decision-store writes)
-----------------------------------------------------------
Route all decision-store writes through app.core.ai_decision_logger.append_decision()
(lock + tail-dedupe), with safe fallback to raw append if logger signature differs.

Patch (2025-12-14a) ✅ FIX (Trade-ID namespacing + source_trade_id)
-------------------------------------------------------------------
If a signal provides a trade_id, that is treated as *source_trade_id*.
We then compute an *effective* per-account client_trade_id so subaccounts do not collide.

- source_trade_id: the original ID from the signal / forced / generated
- client_trade_id: the effective, namespaced ID used for decisions/enforcement/broker
- We write source_trade_id into every decision/audit row.
- We log: trade_id_map source=... -> effective=...

Patch (2025-12-18a) ✅ FIX (DRY_RUN equity source)
-------------------------------------------------
When EXEC_DRY_RUN=True (or LEARN_DRY / PAPER), DO NOT call get_equity_usdt()
because it hits Bybit wallet endpoints and breaks deterministic testing.
Instead:
- use PaperBroker ledger equity if available
- else fallback to a stable default (1000.0)

Patch (2025-12-18b) ✅ FIX (PAPER AI payload completeness)
---------------------------------------------------------
In PAPER path, log_features_at_open + build_setup_context must receive the paper
features object that includes stop/tp fields (paper_stop_pct, tp_mult, stop_price, take_profit_price).

Patch (2025-12-18c) ✅ FIX (Cursor self-heal + idle heartbeat)
--------------------------------------------------------------
Prevents “silent freeze” when cursor points into the middle of a JSONL line or
stale offsets after file rewrites.
- On startup: validate cursor points to a JSONL boundary; if not, rewind to last newline or reset to 0.
- Runtime: if cursor appears off-boundary, self-heal.
- Log idle heartbeat so “doing nothing” is visible.

Patch (2025-12-19a) ✅ FIX (Cursor EOF handling)
------------------------------------------------
EOF (cursor == file_size) is a valid boundary for JSONL.
Do NOT heal at EOF or you'll re-read the last line forever.
"""

from __future__ import annotations

import os
import json
import asyncio
import time
import hashlib
from decimal import Decimal
from pathlib import Path
from typing import Dict, Optional, List, Any, Iterable, Tuple

from app.core.config import settings

# ---------- Robust logger import ---------- #
try:
    from app.core.logger import get_logger, bind_context  # type: ignore
except Exception:
    try:
        from app.core.log import get_logger as _get_logger  # type: ignore
        import logging

        def bind_context(logger: "logging.Logger", **ctx):
            return logger

        get_logger = _get_logger  # type: ignore
    except Exception:
        import logging

        def get_logger(name: str) -> "logging.Logger":  # type: ignore
            logger_ = logging.getLogger(name)
            if not logger_.handlers:
                handler = logging.StreamHandler()
                fmt = logging.Formatter("%(asctime)s [%(levelname)s] [%(name)s] %(message)s")
                handler.setFormatter(fmt)
                logger_.addHandler(handler)
            logger_.setLevel(logging.INFO)
            return logger_

        def bind_context(logger: "logging.Logger", **ctx):  # type: ignore
            return logger


from app.core.bybit_client import Bybit
from app.core.notifier_bot import tg_send
from app.core.trade_classifier import classify as classify_trade
from app.core.corr_gate_v2 import allow as corr_allow
from app.core.sizing import bayesian_size, risk_capped_qty
from app.core.strategy_gate import (
    get_strategies_for_signal,
    strategy_label,
    strategy_risk_pct,
)
from app.core.portfolio_guard import can_open_trade
from app.core.flashback_common import get_equity_usdt, record_heartbeat, GLOBAL_BREAKER
from app.core.session_guard import should_block_trading
from app.ai.setup_memory_policy import get_risk_multiplier, get_min_ai_score

from app.core.orders_bus import record_order_event
from app.ai.feature_logger import log_features_at_open
from app.ai.ai_events_spine import build_setup_context, publish_ai_event

# ✅ Decision enforcer (manual blocks + pilot decisions)
from app.ai.ai_decision_enforcer import enforce_decision

# ✅ Pilot (legacy decision schema v1) producer
try:
    from app.bots.ai_pilot import pilot_decide  # type: ignore
except Exception:
    pilot_decide = None  # type: ignore

try:
    from app.ai.policy_log import record_policy_decision  # type: ignore
except Exception:  # pragma: no cover
    def record_policy_decision(*args, **kwargs):
        return None

from app.core.position_bus import get_positions_snapshot as bus_get_positions_snapshot
from app.sim.paper_broker import PaperBroker  # type: ignore

log = get_logger("executor_v2")

EXEC_DRY_RUN: bool = os.getenv("EXEC_DRY_RUN", "true").strip().lower() in ("1", "true", "yes", "y", "on")

# ✅ Decision enforcement toggles
EXEC_ENFORCE_DECISIONS: bool = os.getenv("EXEC_ENFORCE_DECISIONS", "true").strip().lower() in ("1", "true", "yes", "y", "on")
EXEC_FORCE_TRADE_ID: str = os.getenv("EXEC_FORCE_TRADE_ID", "").strip()

ROOT: Path = settings.ROOT
SIGNAL_FILE: Path = ROOT / "signals" / "observed.jsonl"
CURSOR_FILE: Path = ROOT / "state" / "observed.cursor"

SIGNAL_FILE.parent.mkdir(parents=True, exist_ok=True)
CURSOR_FILE.parent.mkdir(parents=True, exist_ok=True)

LATENCY_LOG_PATH: Path = ROOT / "state" / "latency_exec.jsonl"
LATENCY_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)

try:
    LATENCY_WARN_MS = int(os.getenv("EXECUTOR_LATENCY_WARN_MS", "1500"))
except Exception:
    LATENCY_WARN_MS = 1500

SUSPECT_LOCK_PATH: Path = ROOT / "state" / "execution_suspect.lock"

# ✅ Decisions store (for enforcer + joiner)
DECISIONS_PATH: Path = ROOT / "state" / "ai_decisions.jsonl"
DECISIONS_PATH.parent.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# ✅ Hardened decision logger import (lock + tail-dedupe)
# ---------------------------------------------------------------------------
try:
    from app.core.ai_decision_logger import append_decision as _append_decision_hardened  # type: ignore
except Exception:
    _append_decision_hardened = None  # type: ignore

# ---------------------------------------------------------------------------
# Cursor hardening toggles (2025-12-18c)
# ---------------------------------------------------------------------------
def _env_int(name: str, default: str) -> int:
    try:
        return int(os.getenv(name, default).strip())
    except Exception:
        return int(default)

def _env_float(name: str, default: str) -> float:
    try:
        return float(os.getenv(name, default).strip())
    except Exception:
        return float(default)

def _env_bool(name: str, default: str = "true") -> bool:
    raw = os.getenv(name, default)
    return str(raw).strip().lower() in ("1", "true", "yes", "y", "on")

EXEC_CURSOR_SELF_HEAL: bool = _env_bool("EXEC_CURSOR_SELF_HEAL", "true")
EXEC_IDLE_HEARTBEAT_SEC: float = _env_float("EXEC_IDLE_HEARTBEAT_SEC", "10")
EXEC_CURSOR_HEAL_READBACK_BYTES: int = _env_int("EXEC_CURSOR_HEAL_READBACK_BYTES", "4096")
EXEC_CURSOR_BADLINE_RESET: bool = _env_bool("EXEC_CURSOR_BADLINE_RESET", "true")


# ---------------------------------------------------------------------------
# BYBIT CLIENTS — ONE PER SUBUID (OR MAIN) + PAPER BROKERS
# ---------------------------------------------------------------------------

_TRADE_CLIENTS: Dict[str, Bybit] = {}
_PAPER_BROKER_CACHE: Dict[str, PaperBroker] = {}


def get_trade_client(sub_uid: Optional[str]) -> Bybit:
    key = str(sub_uid) if sub_uid else "main"
    client = _TRADE_CLIENTS.get(key)
    if client is not None:
        return client
    client = Bybit("trade", sub_uid=sub_uid) if sub_uid else Bybit("trade")
    _TRADE_CLIENTS[key] = client
    return client


def get_paper_broker(account_label: str, starting_equity: float) -> PaperBroker:
    broker = _PAPER_BROKER_CACHE.get(account_label)
    if broker is not None:
        return broker
    broker = PaperBroker.load_or_create(account_label=account_label, starting_equity=starting_equity)
    _PAPER_BROKER_CACHE[account_label] = broker
    return broker


def _paper_equity_usd(account_label: str, fallback: float = 1000.0) -> float:
    """
    Best-effort equity source for PAPER/DRY_RUN:
    - Prefer PaperBroker ledger equity if present
    - Otherwise return fallback
    Never throws.
    """
    try:
        b = get_paper_broker(account_label=account_label, starting_equity=float(fallback))
        for attr in ("equity", "equity_usd", "equity_now", "equity_now_usd"):
            v = getattr(b, attr, None)
            if v is None:
                continue
            try:
                return float(v)
            except Exception:
                pass
        return float(fallback)
    except Exception:
        return float(fallback)


# ---------- CURSOR HELPERS ---------- #

def load_cursor() -> int:
    if not CURSOR_FILE.exists():
        return 0
    try:
        return int(CURSOR_FILE.read_text().strip() or "0")
    except Exception:
        return 0


def save_cursor(pos: int) -> None:
    try:
        CURSOR_FILE.write_text(str(pos))
    except Exception as e:
        log.warning("failed to save cursor %s: %r", pos, e)


def _cursor_heal_to_line_boundary(pos: int) -> int:
    """
    Make sure the cursor points to a valid JSONL boundary.

    ✅ Key rule:
    - pos == file_size (EOF) is VALID. Do not heal at EOF.

    Behavior:
    - If pos=0: OK
    - If pos > file_size: reset to 0 (file truncated/rewritten)
    - If pos inside a line: rewind to the last newline + 1
    - If we can't find a newline: reset to 0 (optional)
    Never throws.
    """
    try:
        if not SIGNAL_FILE.exists():
            return 0

        size = SIGNAL_FILE.stat().st_size
        if size <= 0:
            return 0

        if pos < 0:
            pos = 0

        # ✅ EOF is a valid boundary
        if pos == size:
            return pos

        # If cursor beyond EOF, file likely truncated or rotated
        if pos > size:
            return 0

        if pos == 0:
            return 0

        with SIGNAL_FILE.open("rb") as f:
            # ✅ If previous byte is '\n', pos is already on a boundary
            try:
                f.seek(pos - 1)
                prev = f.read(1)
                if prev == b"\n":
                    return pos
            except Exception:
                pass

            # If we're at a line start and it looks like JSON, keep it
            f.seek(pos)
            raw = f.readline()
            if raw:
                s = raw.lstrip()
                if s.startswith(b"{"):
                    return pos

            # Otherwise, rewind a window and find the last newline before pos
            back = min(EXEC_CURSOR_HEAL_READBACK_BYTES, pos)
            f.seek(pos - back)
            chunk = f.read(back)
            if not chunk:
                return 0

            idx = chunk.rfind(b"\n")
            if idx == -1:
                return 0 if EXEC_CURSOR_BADLINE_RESET else pos

            healed = (pos - back) + idx + 1
            if healed < 0:
                healed = 0
            if healed > size:
                healed = 0

            # If healed lands exactly at EOF, that's fine
            if healed == size:
                return healed

            # Quick validation: next non-space should look like JSON
            f.seek(healed)
            raw2 = f.readline()
            if raw2 and raw2.lstrip().startswith(b"{"):
                return healed

            return 0 if EXEC_CURSOR_BADLINE_RESET else healed
    except Exception:
        return 0


# ---------- LATENCY HELPERS ---------- #

def record_latency(event: str, symbol: str, strat: str, mode: str, duration_ms: int, extra: Optional[Dict[str, Any]] = None) -> None:
    row: Dict[str, Any] = {
        "ts_ms": int(time.time() * 1000),
        "event": event,
        "symbol": symbol,
        "strategy": strat,
        "mode": mode,
        "duration_ms": int(duration_ms),
    }
    if extra:
        row["extra"] = extra
    try:
        with LATENCY_LOG_PATH.open("ab") as f:
            f.write(json.dumps(row).encode("utf-8") + b"\n")
    except Exception as e:
        log.warning("failed to write latency log: %r", e)


# ---------------------------------------------------------------------------
# Raw JSONL append helper (fallback only)
# ---------------------------------------------------------------------------

def _append_jsonl(path: Path, payload: Dict[str, Any]) -> None:
    try:
        with path.open("ab") as f:
            f.write(json.dumps(payload, ensure_ascii=False).encode("utf-8") + b"\n")
    except Exception as e:
        log.warning("failed to append jsonl to %s: %r", path, e)


# ---------------------------------------------------------------------------
# ✅ Decision-store append wrapper (prefer hardened logger)
# ---------------------------------------------------------------------------

def _append_decision(payload: Dict[str, Any]) -> None:
    """
    Append a decision row to the canonical decisions store.

    Prefer app.core.ai_decision_logger.append_decision() (lock + tail-dedupe).
    Fall back to raw append if the hardened logger is unavailable or signature differs.
    """
    if _append_decision_hardened is not None:
        try:
            _append_decision_hardened(payload)  # type: ignore[arg-type]
            return
        except TypeError:
            try:
                _append_decision_hardened(payload, path=DECISIONS_PATH)  # type: ignore[arg-type]
                return
            except Exception as e:
                log.warning("append_decision(payload, path=...) failed; falling back: %r", e)
        except Exception as e:
            log.warning("append_decision(payload) failed; falling back: %r", e)

    _append_jsonl(DECISIONS_PATH, payload)


# ---------------------------------------------------------------------------
# ✅ Trade-ID namespacing helpers (2025-12-14a)
# ---------------------------------------------------------------------------

def _safe_str(x: Any) -> str:
    try:
        return str(x) if x is not None else ""
    except Exception:
        return ""


def _make_effective_trade_id(source_trade_id: str, account_label: str, sub_uid: str, strategy_id: str) -> str:
    """
    Make a per-account effective trade id to prevent collisions when a signal supplies trade_id.

    Constraints:
    - Must be deterministic
    - Must be short enough for orderLinkId in LIVE (conservatively keep <= 36)
    """
    src = _safe_str(source_trade_id).strip() or "NO_SRC"
    acct = _safe_str(account_label).strip() or (_safe_str(sub_uid).strip() or "main")
    candidate = f"{acct}:{src}"

    if len(candidate) <= 36:
        return candidate

    h = hashlib.sha1(src.encode("utf-8", errors="ignore")).hexdigest()[:16]
    candidate2 = f"{acct}:{h}"
    if len(candidate2) <= 36:
        return candidate2

    h2 = hashlib.sha1(acct.encode("utf-8", errors="ignore")).hexdigest()[:8]
    return f"{h2}:{h}"


# ---------------------------------------------------------------------------
# ✅ Pilot decision emission (THIS is what enforcer consumes)
# ---------------------------------------------------------------------------

def emit_pilot_input_decision(setup_event: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Hardened pilot INPUT decision emitter.
    Guarantees schema_version == 1 and a usable decision row for the enforcer.
    """
    if pilot_decide is None:
        return None

    try:
        raw = pilot_decide(setup_event)
    except Exception as e:
        log.warning("pilot_decide crashed (non-fatal): %r", e)
        raw = None

    if not isinstance(setup_event, dict):
        return None

    trade_id = str(setup_event.get("trade_id") or "").strip()
    if not trade_id:
        return None

    client_trade_id = str(setup_event.get("client_trade_id") or trade_id).strip()
    source_trade_id = setup_event.get("source_trade_id")

    symbol = str(setup_event.get("symbol") or "").strip().upper()
    account_label = str(setup_event.get("account_label") or "").strip()
    timeframe = str(setup_event.get("timeframe") or "").strip()

    d = raw if isinstance(raw, dict) else {}

    decision = str(
        d.get("decision")
        or d.get("decision_code")
        or d.get("code")
        or d.get("action")
        or "COLD_START"
    ).strip()

    allow = d.get("allow")
    sm = d.get("size_multiplier")

    if sm is None:
        pa = d.get("proposed_action") if isinstance(d.get("proposed_action"), dict) else {}
        sm = pa.get("size_multiplier")

    gates = d.get("gates") if isinstance(d.get("gates"), dict) else {}
    reason = str(d.get("reason") or gates.get("reason") or "pilot_input").strip()

    if allow is None:
        allow = decision in ("ALLOW_TRADE", "COLD_START")

    try:
        sm_f = float(sm) if sm is not None else (0.25 if decision == "COLD_START" else (1.0 if allow else 0.0))
    except Exception:
        sm_f = 0.25 if decision == "COLD_START" else (1.0 if allow else 0.0)

    if sm_f < 0:
        sm_f = 0.0
    if allow and sm_f <= 0:
        sm_f = 1.0

    row = {
        "schema_version": 1,
        "ts": int(time.time() * 1000),
        "trade_id": trade_id,
        "client_trade_id": client_trade_id,
        "source_trade_id": source_trade_id,
        "symbol": symbol,
        "account_label": account_label,
        "timeframe": timeframe,
        "decision": decision,
        "allow": bool(allow),
        "size_multiplier": float(sm_f),
        "gates": {"reason": reason},
        "meta": {"source": "pilot_input_normalized"},
    }

    _append_decision(row)
    return row



def emit_ai_decision(
    *,
    trade_id: str,
    client_trade_id: str,
    source_trade_id: Optional[str],
    symbol: str,
    account_label: str,
    sub_uid: str,
    strategy_id: str,
    strategy_name: str,
    timeframe: str,
    side: str,
    mode: str,
    allow: bool,
    decision_code: str,
    reason: str,
    model_used: Optional[str] = None,
    regime: Optional[str] = None,
    confidence_source: Optional[str] = None,
    learning_tags: Optional[list[str]] = None,
    ai_score: Optional[float] = None,
    tier_used: Optional[str] = None,
    gates_reason: Optional[str] = None,
    memory_id: Optional[str] = None,
    memory_score: Optional[float] = None,
    size_multiplier: Optional[float] = None,
    extra: Optional[Dict[str, Any]] = None,
) -> None:
    row: Dict[str, Any] = {
        "ts_ms": int(time.time() * 1000),
        "event_type": "ai_decision",
        "trade_id": str(trade_id),
        "client_trade_id": str(client_trade_id),
        "source_trade_id": (str(source_trade_id) if source_trade_id else None),
        "symbol": str(symbol),
        "account_label": str(account_label),
        "sub_uid": (str(sub_uid) if sub_uid else None),
        "strategy_id": str(strategy_id),
        "strategy_name": str(strategy_name),
        "timeframe": str(timeframe),
        "model_used": model_used,
        "regime": regime,
        "confidence_source": confidence_source,
        "learning_tags": learning_tags or [],
        "side": str(side),
        "mode": str(mode),
        "allow": bool(allow),
        "decision_code": str(decision_code),
        "reason": str(reason),
        "ai_score": (float(ai_score) if ai_score is not None else None),
        "tier_used": tier_used,
        "gates_reason": gates_reason,
        "memory_id": memory_id,
        "memory_score": (float(memory_score) if memory_score is not None else None),
        "size_multiplier": (float(size_multiplier) if size_multiplier is not None else None),
    }
    if extra:
        row["extra"] = extra
    _append_decision(row)


# ---------- AI GATE WRAPPER ---------- #

def run_ai_gate(signal: Dict[str, Any], strat_id: str, bound_log) -> Dict[str, Any]:
    decision: Dict[str, Any] = {"allow": True, "score": None, "reason": "default_allow_fallback", "features": {}}

    try:
        clf = classify_trade(signal, strat_id)
    except Exception as e:
        bound_log.warning("AI classifier crashed for [%s]: %r — bypassing gate (allow=True).", strat_id, e)
        decision = {"allow": True, "score": None, "reason": f"classifier_error: {e}", "features": {}}
        record_policy_decision(strategy_id=strat_id, allow=decision["allow"], score=decision["score"], reason=decision["reason"], signal=signal)
        return decision

    if not isinstance(clf, dict):
        bound_log.warning("AI classifier returned non-dict for [%s]: %r — treating as allow=True.", strat_id, clf)
        decision = {"allow": True, "score": None, "reason": "classifier_non_dict", "features": {}}
        record_policy_decision(strategy_id=strat_id, allow=decision["allow"], score=decision["score"], reason=decision["reason"], signal=signal)
        return decision

    allow = bool(clf.get("allow", True))
    score = clf.get("score")
    reason = clf.get("reason") or clf.get("why") or "ok"
    features = clf.get("features") or {}

    min_score = get_min_ai_score(strat_id)
    try:
        score_f = float(score) if score is not None else None
    except Exception:
        score_f = None

    if min_score > 0 and score_f is not None and score_f < min_score:
        bound_log.info("AI score %.3f < min threshold %.3f for [%s]; rejecting trade.", score_f, min_score, strat_id)
        decision = {"allow": False, "score": score_f, "reason": f"score_below_min ({score_f:.3f} < {min_score:.3f})", "features": features}
        record_policy_decision(strategy_id=strat_id, allow=decision["allow"], score=decision["score"], reason=decision["reason"], signal=signal)
        return decision

    if not allow:
        bound_log.info("AI gate rejected [%s]: %s", strat_id, reason)

    decision = {"allow": allow, "score": score_f, "reason": reason, "features": features}
    record_policy_decision(strategy_id=strat_id, allow=decision["allow"], score=decision["score"], reason=decision["reason"], signal=signal)
    return decision


# ---------- SIGNAL PROCESSOR ---------- #

def _normalize_strategies_for_signal(strategies: Any) -> Iterable[Tuple[str, Dict[str, Any]]]:
    if not strategies:
        return []
    if isinstance(strategies, dict):
        return strategies.items()
    if isinstance(strategies, (list, tuple)):
        if not strategies:
            return []
        first = strategies[0]
        if isinstance(first, (list, tuple)) and len(first) == 2:
            return strategies
        if isinstance(first, dict):
            normalized: List[Tuple[str, Dict[str, Any]]] = []
            for cfg in strategies:
                if not isinstance(cfg, dict):
                    continue
                name = cfg.get("name") or cfg.get("id") or cfg.get("label") or cfg.get("strategy_name") or "unnamed_strategy"
                normalized.append((str(name), cfg))
            return normalized
        return []
    return []


async def process_signal_line(line: str) -> None:
    try:
        sig = json.loads(line)
    except Exception:
        log.warning("Invalid JSON in observed.jsonl: %r", line[:200])
        return

    symbol = sig.get("symbol")
    tf = sig.get("timeframe") or sig.get("tf")
    if not symbol or not tf:
        return

    strategies = get_strategies_for_signal(symbol, tf)
    strat_items = _normalize_strategies_for_signal(strategies)
    if not strat_items:
        return

    for strat_name, strat_cfg in strat_items:
        try:
            await handle_strategy_signal(strat_name, strat_cfg, sig)
        except Exception as e:
            log.exception("Strategy error (%s): %r", strat_name, e)


# ---------- STRATEGY PROCESSOR ---------- #

def _automation_mode_from_cfg(cfg: Dict[str, Any]) -> str:
    mode = str(cfg.get("automation_mode", "OFF")).upper().strip()
    if mode not in ("OFF", "LEARN_DRY", "LIVE_CANARY", "LIVE_FULL"):
        mode = "OFF"
    return mode


def _normalize_paper_side(signal_side: str) -> str:
    s = str(signal_side or "").strip().lower()
    if s in ("buy", "long"):
        return "long"
    if s in ("sell", "short"):
        return "short"
    raise ValueError(f"Unsupported side value for paper entry: {signal_side!r}")


async def handle_strategy_signal(strat_name: str, strat_cfg: Dict[str, Any], sig: Dict[str, Any]) -> None:
    strat_id = strategy_label(strat_cfg)
    bound = bind_context(log, strat=strat_id)

    enabled = bool(strat_cfg.get("enabled", False))
    mode_raw = _automation_mode_from_cfg(strat_cfg)

    if not enabled or mode_raw == "OFF":
        bound.debug("strategy disabled or automation_mode=OFF")
        return

    symbol = sig.get("symbol")
    tf = sig.get("timeframe") or sig.get("tf")
    side = sig.get("side")

    price = sig.get("price") or sig.get("last") or sig.get("close")
    debug = sig.get("debug") or {}
    if price is None and isinstance(debug, dict):
        for key in ("last_close", "last", "close"):
            v = debug.get(key)
            if v is not None:
                price = v
                break

    if not symbol or not tf or not side or price is None:
        bound.warning("missing required fields in signal: %r", sig)
        return

    try:
        price_f = float(price)
    except Exception:
        bound.warning("invalid price in signal: %r", sig)
        return

    if EXEC_DRY_RUN:
        trade_mode = "PAPER"
    else:
        if mode_raw == "LEARN_DRY":
            trade_mode = "PAPER"
        elif mode_raw == "LIVE_CANARY":
            trade_mode = "LIVE_CANARY"
        elif mode_raw == "LIVE_FULL":
            trade_mode = "LIVE_FULL"
        else:
            trade_mode = mode_raw

    sub_uid = str(strat_cfg.get("sub_uid") or strat_cfg.get("subAccountId") or strat_cfg.get("accountId") or strat_cfg.get("subId") or "")
    account_label = str(strat_cfg.get("account_label") or strat_cfg.get("label") or strat_cfg.get("account_label_slug") or "main")

    lock_active = SUSPECT_LOCK_PATH.exists()
    try:
        breaker_on = bool(GLOBAL_BREAKER.get("on", False))
    except Exception:
        breaker_on = False

    is_training_mode = EXEC_DRY_RUN or mode_raw == "LEARN_DRY"
    started_ms = int(time.time() * 1000)

    try:
        if should_block_trading():
            bound.info("Session Guard blocking new trades (limits reached).")
            return
    except Exception as e:
        bound.warning("Session Guard error; bypassing: %r", e)

    # -----------------------------------------------------------------------
    # ✅ trade_id selection (deterministic priority) → source_trade_id
    # -----------------------------------------------------------------------
    ts_open_ms = int(time.time() * 1000)
    strat_safe = strat_id.replace(" ", "_").replace("(", "").replace(")", "")
    default_source_trade_id = f"{strat_safe}-{ts_open_ms}"

    sig_trade_id_raw = ""
    try:
        sig_trade_id_raw = str(sig.get("trade_id") or sig.get("client_trade_id") or "").strip()
    except Exception:
        sig_trade_id_raw = ""

    used_sig_trade_id = bool(sig_trade_id_raw)
    used_force_trade_id = False

    if used_sig_trade_id:
        source_trade_id = sig_trade_id_raw
        trade_id_source = "signal"
    elif EXEC_FORCE_TRADE_ID:
        source_trade_id = EXEC_FORCE_TRADE_ID
        used_force_trade_id = True
        trade_id_source = "exec_force"
    else:
        source_trade_id = default_source_trade_id
        trade_id_source = "generated"

    # ✅ Effective per-account client_trade_id (prevents collisions)
    client_trade_id = _make_effective_trade_id(source_trade_id, account_label=account_label, sub_uid=sub_uid, strategy_id=strat_id)
    trade_id = client_trade_id  # PAPER uses this; LIVE later switches to orderId after entry

    bound.info(
        "trade_id_map source=%s -> effective=%s account=%s sub_uid=%s strat=%s",
        source_trade_id, client_trade_id, account_label, (sub_uid or None), strat_id
    )

    # -----------------------------------------------------------------------
    # ✅ FIX: produce pilot legacy decision row BEFORE enforcement
    # -----------------------------------------------------------------------
    pilot_setup_event = {
        "trade_id": client_trade_id,
        "client_trade_id": client_trade_id,
        "source_trade_id": source_trade_id,
        "symbol": symbol,
        "timeframe": str(tf),
        "setup_type": str(sig.get("setup_type") or "unknown"),
        "account_label": account_label,
        "policy": {"policy_hash": str(strat_cfg.get("policy_hash") or (strat_cfg.get("policy", {}) or {}).get("policy_hash") or "")},
        "payload": {
            "features": {
                "memory_fingerprint": (
                    (sig.get("payload", {}).get("features", {}).get("memory_fingerprint") if isinstance(sig.get("payload"), dict) else None)
                    or (sig.get("debug", {}).get("memory_fingerprint") if isinstance(sig.get("debug"), dict) else None)
                    or (sig.get("memory_fingerprint"))
                    or ""
                ),
            }
        },
    }

    ph_sig = None
    try:
        ph_sig = (sig.get("policy", {}).get("policy_hash") if isinstance(sig.get("policy"), dict) else None)
    except Exception:
        ph_sig = None
    if ph_sig:
        pilot_setup_event["policy"]["policy_hash"] = str(ph_sig)

    pilot_row = emit_pilot_input_decision(pilot_setup_event)

    # -----------------------------------------------------------------------
    # ✅ HARD GATE: ENFORCE DECISION BEFORE SIZING/EXECUTION (effective id)
    # -----------------------------------------------------------------------
    size_multiplier_applied = 1.0
    enforced_reason = "not_enforced"
    enforced_code = None

    if EXEC_ENFORCE_DECISIONS:
        try:
            enforced = enforce_decision(client_trade_id, account_label=account_label)
        except Exception as e:
            enforced = {"allow": True, "size_multiplier": 1.0, "decision_code": None, "reason": f"enforcer_error:{e}"}

        allow = bool(enforced.get("allow", True))
        enforced_code = enforced.get("decision_code")
        enforced_reason = str(enforced.get("reason") or "ok")

        sm_raw = enforced.get("size_multiplier", 1.0)
        try:
            sm = float(sm_raw) if sm_raw is not None else 1.0
        except Exception:
            sm = 1.0

        if not allow:
            emit_ai_decision(
                trade_id=client_trade_id,
                client_trade_id=client_trade_id,
                source_trade_id=source_trade_id,
                symbol=symbol,
                account_label=account_label,
                sub_uid=sub_uid,
                strategy_id=strat_id,
                strategy_name=strat_cfg.get("name", strat_name),
                timeframe=str(tf),
                side=str(side),
                mode=trade_mode,
                allow=False,
                decision_code=str(enforced_code or "BLOCK_TRADE"),
                reason=enforced_reason,
                ai_score=None,
                size_multiplier=0.0,
                extra={
                    "stage": "decision_enforced_pre_sizing",
                    "trade_id_source": trade_id_source,
                    "sig_trade_id_present": bool(used_sig_trade_id),
                    "forced_trade_id": bool(used_force_trade_id),
                    "pilot_emitted": bool(pilot_row),
                    "enforced_code": str(enforced_code or ""),
                    "enforced_reason": str(enforced_reason or ""),
                    "enforced_size_multiplier": 0.0,
                },
            )
            bound.info("⛔ Decision enforcer BLOCKED (pre-sizing) trade_id=%s reason=%s", client_trade_id, enforced_reason)
            try:
                tg_send(f"⛔ Trade BLOCKED by decision enforcer (pre-sizing): trade_id={client_trade_id} source_trade_id={source_trade_id} symbol={symbol} strat={strat_id} reason={enforced_reason}")
            except Exception:
                pass
            return

        if sm > 0:
            size_multiplier_applied = sm

        # ✅ NEW: write post-enforce pilot row (dedupe-distinct) so joiners/audits can see enforced multiplier
        try:
            emit_pilot_enforced_decision(
                pilot_setup_event,
                enforced,
                pilot_row=pilot_row,
                size_multiplier_applied=float(size_multiplier_applied),
                enforced_code=str(enforced_code or ""),
                enforced_reason=str(enforced_reason or "ok"),
            )
        except Exception:
            pass

    effective_code = str(enforced_code) if enforced_code else "ALLOW_TRADE"
    effective_reason = str(enforced_reason) if (enforced_reason and enforced_reason != "not_enforced") else "passed"

    # -----------------------------------------------------------------------
    # AI gate (classifier/min score)
    # -----------------------------------------------------------------------
    ai = run_ai_gate(sig, strat_id, bound)
    if not ai["allow"]:
        emit_ai_decision(
            trade_id=client_trade_id,
            client_trade_id=client_trade_id,
            source_trade_id=source_trade_id,
            symbol=symbol,
            account_label=account_label,
            sub_uid=sub_uid,
            strategy_id=strat_id,
            strategy_name=strat_cfg.get("name", strat_name),
            timeframe=str(tf),
            side=str(side),
            mode=trade_mode,
            allow=False,
            decision_code="REJECT_TRADE",
            reason=str(ai.get("reason") or "ai_reject"),
            ai_score=ai.get("score"),
            extra={
                "stage": "ai_gate",
                "trade_id_source": trade_id_source,
                "sig_trade_id_present": bool(used_sig_trade_id),
                "forced_trade_id": bool(used_force_trade_id),
                "pilot_emitted": bool(pilot_row),
                "enforced_code": effective_code,
                "enforced_reason": effective_reason,
                "enforced_size_multiplier": float(size_multiplier_applied),
            },
        )
        return

    # -----------------------------------------------------------------------
    # Correlation gate
    # -----------------------------------------------------------------------
    try:
        allowed_corr, corr_reason = corr_allow(symbol)
    except Exception as e:
        bound.warning("Correlation gate error for %s: %r; bypassing.", symbol, e)
        allowed_corr, corr_reason = True, "corr_gate_v2 exception, bypassed"

    if not allowed_corr:
        emit_ai_decision(
            trade_id=client_trade_id,
            client_trade_id=client_trade_id,
            source_trade_id=source_trade_id,
            symbol=symbol,
            account_label=account_label,
            sub_uid=sub_uid,
            strategy_id=strat_id,
            strategy_name=strat_cfg.get("name", strat_name),
            timeframe=str(tf),
            side=str(side),
            mode=trade_mode,
            allow=False,
            decision_code="REJECT_TRADE",
            reason=f"corr_gate:{corr_reason}",
            ai_score=ai.get("score"),
            extra={
                "stage": "corr_gate",
                "trade_id_source": trade_id_source,
                "sig_trade_id_present": bool(used_sig_trade_id),
                "forced_trade_id": bool(used_force_trade_id),
                "pilot_emitted": bool(pilot_row),
                "enforced_code": effective_code,
                "enforced_reason": effective_reason,
                "enforced_size_multiplier": float(size_multiplier_applied),
            },
        )
        return

    # -----------------------------------------------------------------------
    # Risk/Sizing inputs (✅ size_multiplier applied BEFORE sizing deterministically)
    # -----------------------------------------------------------------------
    try:
        base_risk_pct = Decimal(str(strategy_risk_pct(strat_cfg)))
    except Exception:
        base_risk_pct = Decimal("0")

    risk_mult = Decimal(str(get_risk_multiplier(strat_id)))
    eff_risk_pct = base_risk_pct * risk_mult

    try:
        eff_risk_pct = eff_risk_pct * Decimal(str(size_multiplier_applied))
    except Exception:
        pass

    if eff_risk_pct <= 0:
        bound.info("effective risk_pct <= 0 for %s; skipping.", strat_id)
        return

    # ✅ FIX: DRY_RUN/PAPER must not hit Bybit wallet endpoints
    try:
        if EXEC_DRY_RUN or mode_raw == "LEARN_DRY" or trade_mode == "PAPER":
            equity_val = Decimal(str(_paper_equity_usd(account_label=account_label, fallback=1000.0)))
        else:
            equity_val = Decimal(str(get_equity_usdt()))
    except Exception as e:
        bound.warning("equity fetch failed: %r; assuming equity=1000.", e)
        equity_val = Decimal("1000")

    stop_pct_for_size = 0.005
    stop_distance = Decimal(str(price_f * stop_pct_for_size))

    qty_suggested, risk_usd = bayesian_size(
        symbol=symbol,
        equity_usd=equity_val,
        risk_pct=float(eff_risk_pct),
        stop_distance=stop_distance,
    )

    if qty_suggested <= 0 or risk_usd <= 0:
        bound.info("bayesian_size returned non-positive sizing for %s; equity=%s risk_pct=%s", strat_id, equity_val, eff_risk_pct)
        return

    qty_capped, risk_capped = risk_capped_qty(
        symbol=symbol,
        qty=qty_suggested,
        equity_usd=equity_val,
        max_risk_pct=float(eff_risk_pct),
        stop_distance=stop_distance,
    )

    if qty_capped <= 0 or risk_capped <= 0:
        bound.info("qty <= 0 after risk_capped_qty; skipping entry.")
        return

    try:
        guard_ok, guard_reason = can_open_trade(
            sub_uid=sub_uid or None,
            strategy_name=strat_cfg.get("name", strat_name),
            risk_usd=risk_capped,
            equity_now_usd=equity_val,
        )
    except TypeError:
        try:
            guard_ok = bool(can_open_trade(symbol, float(risk_capped)))
            guard_reason = "legacy_bool_guard"
        except Exception as e:
            bound.warning("Portfolio guard failed for %s: %r; bypassing.", symbol, e)
            guard_ok, guard_reason = True, "guard_exception_bypass"
    except Exception as e:
        bound.warning("Portfolio guard failed for %s: %r; bypassing.", symbol, e)
        guard_ok, guard_reason = True, "guard_exception_bypass"

    if not guard_ok:
        emit_ai_decision(
            trade_id=client_trade_id,
            client_trade_id=client_trade_id,
            source_trade_id=source_trade_id,
            symbol=symbol,
            account_label=account_label,
            sub_uid=sub_uid,
            strategy_id=strat_id,
            strategy_name=strat_cfg.get("name", strat_name),
            timeframe=str(tf),
            side=str(side),
            mode=trade_mode,
            allow=False,
            decision_code="REJECT_TRADE",
            reason=f"portfolio_guard:{guard_reason}",
            ai_score=ai.get("score"),
            extra={
                "stage": "portfolio_guard",
                "trade_id_source": trade_id_source,
                "sig_trade_id_present": bool(used_sig_trade_id),
                "forced_trade_id": bool(used_force_trade_id),
                "pilot_emitted": bool(pilot_row),
                "enforced_code": effective_code,
                "enforced_reason": effective_reason,
                "enforced_size_multiplier": float(size_multiplier_applied),
            },
        )
        bound.info("Portfolio guard blocked trade for %s: %s", symbol, guard_reason)
        return

    decision_done_ms = int(time.time() * 1000)
    record_latency(
        event="decision_pipeline",
        symbol=symbol,
        strat=strat_id,
        mode=trade_mode,
        duration_ms=decision_done_ms - started_ms,
        extra={
            "sub_uid": sub_uid or None,
            "account_label": account_label,
            "equity_usd": float(equity_val),
            "eff_risk_pct": float(eff_risk_pct),
            "lock_active": lock_active,
            "breaker_on": breaker_on,
            "decision_enforced": bool(EXEC_ENFORCE_DECISIONS),
            "decision_size_multiplier": float(size_multiplier_applied),
            "decision_reason": effective_reason,
            "decision_code": effective_code,
            "pilot_emitted": bool(pilot_row),
            "trade_id_source": trade_id_source,
            "source_trade_id": source_trade_id,
        },
    )

    setup_type_val: str = str(sig.get("setup_type") or "unknown")
    base_features: Dict[str, Any] = {
        "schema_version": "setup_features_v1",
        "signal": sig,
        "symbol": symbol,
        "timeframe": str(tf),
        "side": side,
        "account_label": account_label,
        "sub_uid": sub_uid or None,
        "strategy_name": strat_cfg.get("name", strat_name),
        "automation_mode": mode_raw,
        "trade_mode": trade_mode,
        "equity_usd": float(equity_val),
        "risk_usd": float(risk_capped),
        "risk_pct": float(eff_risk_pct),
        "stop_pct_for_size": float(stop_pct_for_size),
        "train_mode": "DRY_RUN_V1" if is_training_mode else "LIVE_OR_CANARY",
        "setup_type": setup_type_val,
        "trade_id": trade_id,
        "client_trade_id": client_trade_id,
        "source_trade_id": source_trade_id,
        "ts_open_ms": ts_open_ms,
        "qty": float(qty_capped),
        "size": float(qty_capped),
        "execution_lock_active": lock_active,
        "execution_global_breaker_on": breaker_on,
        "decision_size_multiplier": float(size_multiplier_applied),
        "decision_enforced": bool(EXEC_ENFORCE_DECISIONS),
        "decision_reason": effective_reason,
        "decision_code": effective_code,
        "trade_id_source": trade_id_source,
        "forced_trade_id": bool(used_force_trade_id),
        "sig_trade_id_present": bool(used_sig_trade_id),
    }

    features_payload: Dict[str, Any] = dict(base_features)
    setup_logged: bool = False

    try:
        ai_score = ai.get("score")
        ai_reason = ai.get("reason", "")
        ai_features = ai.get("features") or {}
        features_payload.update(ai_features)
        features_payload["ai_score"] = float(ai_score) if ai_score is not None else None
        features_payload["ai_reason"] = str(ai_reason)
    except Exception as e:
        bound.warning("feature enrichment failed (non-fatal): %r", e)

    live_mode_requested = mode_raw in ("LIVE_CANARY", "LIVE_FULL")
    live_allowed = live_mode_requested and not lock_active and not EXEC_DRY_RUN and not breaker_on

    # ✅ Truthy PRE audit row
    emit_ai_decision(
        trade_id=client_trade_id,
        client_trade_id=client_trade_id,
        source_trade_id=source_trade_id,
        symbol=symbol,
        account_label=account_label,
        sub_uid=sub_uid,
        strategy_id=strat_id,
        strategy_name=strat_cfg.get("name", strat_name),
        timeframe=str(tf),
        side=str(side),
        mode=trade_mode,
        allow=True,
        decision_code=effective_code,
        reason=effective_reason,
        ai_score=features_payload.get("ai_score"),
        size_multiplier=float(size_multiplier_applied) if size_multiplier_applied != 1.0 else None,
        extra={
            "stage": "pre_entry",
            "risk_usd": float(risk_capped),
            "risk_pct": float(eff_risk_pct),
            "qty": float(qty_capped),
            "decision_enforced": bool(EXEC_ENFORCE_DECISIONS),
            "trade_id_source": trade_id_source,
            "source_trade_id": source_trade_id,
            "sig_trade_id_present": bool(used_sig_trade_id),
            "forced_trade_id": bool(used_force_trade_id),
            "pilot_emitted": bool(pilot_row),
            "enforced_code": effective_code,
            "enforced_reason": effective_reason,
            "enforced_size_multiplier": float(size_multiplier_applied),
        },
    )

    # --- LIVE path ---
    if live_allowed:
        order_id = await execute_entry(
            symbol=symbol,
            signal_side=str(side),
            qty=float(qty_capped),
            price=price_f,
            strat=strat_id,
            mode=trade_mode,
            sub_uid=sub_uid,
            account_label=account_label,
            trade_id=client_trade_id,
            bound_log=bound,
            started_ms=started_ms,
        )
        if not order_id:
            bound.warning("LIVE entry failed; not emitting setup_context (no order_id).")
            return

        trade_id = str(order_id)

        # Also emit pilot decision keyed by orderId for downstream joiners if desired
        try:
            if isinstance(pilot_row, dict):
                pilot_row2 = dict(pilot_row)
                pilot_row2["trade_id"] = trade_id
                pilot_row2["client_trade_id"] = client_trade_id
                pilot_row2["source_trade_id"] = source_trade_id
                _append_decision(pilot_row2)
        except Exception:
            pass

        emit_ai_decision(
            trade_id=trade_id,
            client_trade_id=client_trade_id,
            source_trade_id=source_trade_id,
            symbol=symbol,
            account_label=account_label,
            sub_uid=sub_uid,
            strategy_id=strat_id,
            strategy_name=strat_cfg.get("name", strat_name),
            timeframe=str(tf),
            side=str(side),
            mode=trade_mode,
            allow=True,
            decision_code=effective_code,
            reason=effective_reason,
            ai_score=features_payload.get("ai_score"),
            size_multiplier=float(size_multiplier_applied) if size_multiplier_applied != 1.0 else None,
            extra={
                "stage": "post_entry",
                "order_id": trade_id,
                "join_key": "orderId",
                "decision_enforced": bool(EXEC_ENFORCE_DECISIONS),
                "pilot_emitted": bool(pilot_row),
                "enforced_code": effective_code,
                "enforced_reason": effective_reason,
                "enforced_size_multiplier": float(size_multiplier_applied),
            },
        )

        features_payload["trade_id"] = trade_id
        features_payload["order_id"] = trade_id
        features_payload["client_trade_id"] = client_trade_id
        features_payload["source_trade_id"] = source_trade_id

        try:
            log_features_at_open(
                trade_id=trade_id,
                ts_open_ms=ts_open_ms,
                symbol=symbol,
                sub_uid=sub_uid,
                strategy_name=strat_cfg.get("name", strat_name),
                setup_type=setup_type_val,
                mode=trade_mode,
                features=features_payload,
            )
        except Exception as e:
            bound.warning("log_features_at_open failed (non-fatal): %r", e)

        try:
            setup_event = build_setup_context(
                trade_id=trade_id,
                symbol=symbol,
                account_label=account_label,
                strategy=strat_cfg.get("name", strat_name),
                features=features_payload,
                setup_type=setup_type_val,
                timeframe=str(tf),
                ai_profile=strat_cfg.get("ai_profile") or None,
                extra={
                    "mode": trade_mode,
                    "sub_uid": sub_uid or None,
                    "client_trade_id": client_trade_id,
                    "source_trade_id": source_trade_id,
                    "order_id": trade_id,
                    "join_key": "orderId",
                },
            )
            publish_ai_event(setup_event)
            setup_logged = True
            bound.info("✅ LIVE setup_context emitted trade_id(orderId)=%s client_trade_id=%s source_trade_id=%s symbol=%s", trade_id, client_trade_id, source_trade_id, symbol)
        except Exception as e:
            bound.warning("AI LIVE setup_context logging failed: %r", e)

        return

    # --- PAPER path ---
    if is_training_mode:
        paper_stop_pct = 0.0015
        paper_tp_mult = 1.5
    else:
        paper_stop_pct = 0.005
        paper_tp_mult = 2.0

    try:
        paper_side = _normalize_paper_side(str(side))
    except ValueError as e:
        bound.warning("cannot normalize paper side %r for %s: %r", side, symbol, e)
        return

    stop_distance_f = float(price_f * paper_stop_pct)
    if stop_distance_f <= 0:
        bound.warning("stop_distance <= 0 for %s; skipping PAPER entry.", symbol)
        return

    if paper_side == "long":
        stop_price = max(0.0001, price_f - stop_distance_f)
        take_profit_price = price_f + (paper_tp_mult * stop_distance_f)
    else:
        stop_price = price_f + stop_distance_f
        take_profit_price = max(0.0001, price_f - (paper_tp_mult * stop_distance_f))

    features_for_paper = {
        **(features_payload or base_features),
        "paper_stop_pct": float(paper_stop_pct),
        "paper_tp_mult": float(paper_tp_mult),
        "stop_price": float(stop_price),
        "take_profit_price": float(take_profit_price),
        "trade_id": trade_id,
        "client_trade_id": client_trade_id,
        "source_trade_id": source_trade_id,
        "ts_open_ms": ts_open_ms,
    }

    # ✅ FIX: PAPER must use features_for_paper
    try:
        log_features_at_open(
            trade_id=trade_id,
            ts_open_ms=ts_open_ms,
            symbol=symbol,
            sub_uid=sub_uid,
            strategy_name=strat_cfg.get("name", strat_name),
            setup_type=setup_type_val,
            mode=trade_mode,
            features=features_for_paper,
        )
    except Exception as e:
        bound.warning("log_features_at_open failed (non-fatal): %r", e)

    # ✅ FIX: PAPER must use features_for_paper
    try:
        setup_event = build_setup_context(
            trade_id=trade_id,
            symbol=symbol,
            account_label=account_label,
            strategy=strat_cfg.get("name", strat_name),
            features=features_for_paper,
            setup_type=setup_type_val,
            timeframe=str(tf),
            ai_profile=strat_cfg.get("ai_profile") or None,
            extra={
                "mode": trade_mode,
                "sub_uid": sub_uid or None,
                "client_trade_id": client_trade_id,
                "source_trade_id": source_trade_id,
                "join_key": "client_trade_id",
            },
        )
        publish_ai_event(setup_event)
        setup_logged = True
        bound.info("✅ PAPER setup_context emitted trade_id=%s source_trade_id=%s symbol=%s", trade_id, source_trade_id, symbol)
    except Exception as e:
        bound.warning("AI PAPER setup_context logging failed: %r", e)

    try:
        broker = get_paper_broker(account_label=account_label, starting_equity=float(equity_val) if equity_val > 0 else 1000.0)
        broker.open_position(
            symbol=symbol,
            side=paper_side,
            entry_price=price_f,
            stop_price=stop_price,
            take_profit_price=take_profit_price,
            setup_type=setup_type_val,
            timeframe=str(tf),
            features=features_for_paper,
            extra={
                "mode": trade_mode,
                "sub_uid": sub_uid or None,
                "strategy_name": strat_cfg.get("name", strat_name),
                "setup_logged_by_executor": setup_logged,
                "client_trade_id": client_trade_id,
                "source_trade_id": source_trade_id,
            },
            trade_id=trade_id,
            log_setup=(not setup_logged),
        )

        bound.info(
            "PAPER entry [%s]: %s %s qty=%s @ ~%s (risk_pct=%s stop=%s tp=%s trade_id=%s source_trade_id=%s setup_logged=%s)",
            strat_id, symbol, paper_side, qty_capped, price_f, eff_risk_pct, stop_price, take_profit_price, trade_id, source_trade_id, setup_logged
        )
    except Exception as e:
        bound.warning("PaperBroker entry failed for %s %s: %r", strat_id, symbol, e)


def _normalize_order_side(signal_side: str) -> str:
    s = str(signal_side or "").strip().lower()
    if s in ("buy", "long"):
        return "Buy"
    if s in ("sell", "short"):
        return "Sell"
    raise ValueError(f"Unsupported side value for order: {signal_side!r}")


async def execute_entry(
    symbol: str,
    signal_side: str,
    qty: float,
    price: float,
    strat: str,
    mode: str,
    sub_uid: str,
    account_label: str,
    trade_id: str,
    bound_log,
    started_ms: Optional[int] = None,
) -> Optional[str]:
    client = get_trade_client(sub_uid or None)
    try:
        order_side = _normalize_order_side(signal_side)
    except ValueError as e:
        bound_log.error("cannot normalize side %r for %s: %r", signal_side, symbol, e)
        return None

    order_link_id = trade_id
    success = False
    start_ms = started_ms or int(time.time() * 1000)
    order_id_out: Optional[str] = None

    try:
        resp = client.place_order(
            category="linear",
            symbol=symbol,
            side=order_side,
            qty=qty,
            orderType="Market",
            orderLinkId=order_link_id,
        )
        bound_log.info("LIVE entry executed [%s %s]: %s %s qty=%s client_trade_id=%s resp=%r", mode, strat, symbol, order_side, qty, trade_id, resp)
        success = True

        try:
            result = resp.get("result") if isinstance(resp, dict) else None
            r = result or {}

            order_id = (r.get("orderId") or r.get("order_id") or r.get("orderID"))
            if order_id:
                order_id_out = str(order_id)
            else:
                order_id_out = str(order_link_id)

            status = (r.get("orderStatus") or r.get("order_status") or "New")
            order_type = (r.get("orderType") or r.get("order_type") or "Market")

            price_str = str(r.get("price") or price)
            qty_str = str(r.get("qty") or qty)
            cum_exec_qty = str(r.get("cumExecQty") or r.get("cum_exec_qty") or 0)
            cum_exec_value = str(r.get("cumExecValue") or r.get("cum_exec_value") or 0)
            cum_exec_fee = str(r.get("cumExecFee") or r.get("cum_exec_fee") or 0)

            record_order_event(
                account_label=account_label,
                symbol=symbol,
                order_id=str(order_id_out),
                side=order_side,
                order_type=str(order_type),
                status=str(status),
                event_type="NEW",
                price=price_str,
                qty=qty_str,
                cum_exec_qty=cum_exec_qty,
                cum_exec_value=cum_exec_value,
                cum_exec_fee=cum_exec_fee,
                position_side=None,
                reduce_only=r.get("reduceOnly"),
                client_order_id=order_link_id,
                raw={"api_response": r, "sub_uid": sub_uid, "mode": mode, "strategy": strat},
            )
        except Exception as e:
            bound_log.warning("orders_bus logging failed for %s %s: %r", symbol, order_link_id, e)

        try:
            tg_send(f"🚀 Entry placed [{mode}/{strat}] {symbol} {order_side} qty={qty} client_trade_id={trade_id} order_id={order_id_out}")
        except Exception as e:
            bound_log.warning("telegram send failed: %r", e)

    except Exception as e:
        bound_log.error("order failed for %s %s qty=%s (strat=%s client_trade_id=%s): %r", symbol, order_side, qty, strat, trade_id, e)
        order_id_out = None

    finally:
        end_ms = int(time.time() * 1000)
        duration = end_ms - start_ms
        try:
            record_latency(
                event="entry_order",
                symbol=symbol,
                strat=strat,
                mode=mode,
                duration_ms=duration,
                extra={"sub_uid": sub_uid or None, "account_label": account_label, "qty": qty, "price": price, "success": success, "order_id": order_id_out, "client_trade_id": order_link_id},
            )
            if duration > LATENCY_WARN_MS:
                bound_log.warning("High executor latency for %s (%s): %d ms (threshold=%d ms)", symbol, strat, duration, LATENCY_WARN_MS)
                try:
                    tg_send(f"⚠️ High executor latency [{mode}/{strat}] {symbol} {duration} ms (threshold={LATENCY_WARN_MS} ms)")
                except Exception:
                    pass
        except Exception as e:
            bound_log.warning("latency logging failed for %s %s: %r", symbol, trade_id, e)

    return order_id_out


async def executor_loop() -> None:
    pos = load_cursor()

    # ✅ Cursor self-heal on startup so we never “start inside a line”
    if EXEC_CURSOR_SELF_HEAL:
        healed = _cursor_heal_to_line_boundary(pos)
        if healed != pos:
            log.info("cursor self-heal: %s -> %s (SIGNAL_FILE=%s)", pos, healed, str(SIGNAL_FILE))
            pos = healed
            save_cursor(pos)

    log.info("executor_v2 starting at cursor=%s (EXEC_DRY_RUN=%s)", pos, EXEC_DRY_RUN)

    last_idle_log = time.time()

    while True:
        try:
            record_heartbeat("executor_v2")

            if not SIGNAL_FILE.exists():
                await asyncio.sleep(0.5)
                continue

            file_stat = SIGNAL_FILE.stat()
            file_size = file_stat.st_size

            if pos > file_size:
                log.info("Signal file truncated (size=%s, cursor=%s). Resetting cursor to 0.", file_size, pos)
                pos = 0
                save_cursor(pos)

            # ✅ Runtime cursor heal ONLY when pos is inside the file (NOT at EOF)
            if EXEC_CURSOR_SELF_HEAL and pos > 0 and file_size > 0 and pos < file_size:
                healed = _cursor_heal_to_line_boundary(pos)
                if healed != pos:
                    log.info("cursor runtime-heal: %s -> %s (size=%s)", pos, healed, file_size)
                    pos = healed
                    save_cursor(pos)

            processed = 0
            with SIGNAL_FILE.open("rb") as f:
                f.seek(pos)
                for raw in f:
                    pos = f.tell()
                    try:
                        line = raw.decode("utf-8").strip()
                    except Exception as e:
                        log.warning("executor_v2: failed to decode line at pos=%s: %r", pos, e)
                        continue
                    if not line:
                        continue
                    await asyncio.sleep(0)
                    await process_signal_line(line)
                    processed += 1
                    save_cursor(pos)

            # ✅ Idle heartbeat so you never think it “froze”
            now = time.time()
            if (now - last_idle_log) >= float(EXEC_IDLE_HEARTBEAT_SEC):
                try:
                    age_s = now - file_stat.st_mtime
                except Exception:
                    age_s = -1.0
                log.info(
                    "idle: processed=%s cursor=%s file_size=%s file_age=%.2fs",
                    processed, pos, file_size, float(age_s)
                )
                last_idle_log = now

            await asyncio.sleep(0.25)

        except Exception as e:
            log.exception("executor loop error: %r; backing off 1s", e)
            await asyncio.sleep(1.0)


def main() -> None:
    try:
        asyncio.run(executor_loop())
    except KeyboardInterrupt:
        log.info("executor_v2 stopped by user")


if __name__ == "__main__":
    main()
